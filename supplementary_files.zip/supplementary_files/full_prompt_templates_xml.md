# Full prompt templates and reproducible evaluation workflow for XML-based UML formative feedback

## Overview

This document provides a complete, reproducible prompt and scripting workflow for evaluating student UML models exported from Enterprise Architect in XML format. The workflow is aligned with the article description in which the model evaluates the submitted UML model strictly from the XML export, applies a task-specific rubric, and returns:

- short formative feedback in Slovak consisting of 5 to 7 sentences,
- a numeric score on a 0 to 10 scale,
- a corresponding letter grade on the A to Fx scale.

The workflow is designed to avoid methodological ambiguity. It explicitly instructs the model to evaluate only the XML content, not screenshots or diagram images, and to assign points criterion by criterion before computing the final score and grade.


## Evaluation principles

The model should evaluate the XML export according to the following general principles:

1. Only the XML content and the assignment context may be used as evidence.
2. No assumptions should be made about diagram elements that are not represented in the XML.
3. Formal UML correctness and semantic adequacy should both be considered.
4. Enterprise Architect metadata should be ignored unless it clearly describes actual UML elements, properties, or relations.
5. If some aspect cannot be verified from the XML, this limitation should be stated briefly and unsupported points should not be awarded.
6. Semantically empty compliance should not be rewarded merely because the XML is technically valid.
7. The final output should be structured, reproducible, and easy to parse automatically.

---

## Standardized output requirements

In all cases, the expected output format is standardized so that the model returns:

- short formative feedback in Slovak consisting of 5 to 7 sentences,
- a numeric score on a 0 to 10 scale,
- a letter grade on the A to Fx scale.

For robust downstream processing, the raw model output should be generated as valid JSON.

### Human-readable output form

```text
SPÄTNÁ VÄZBA:
[5 až 7 viet v slovenčine]

SKÓRE: [0.0 až 10.0]
ZNÁMKA: [A/B/C/D/E/Fx]
```

### Structured JSON form

```json
{
  "criterion_scores": [
    {
      "criterion": "string",
      "points_awarded": 0.0,
      "points_max": 0.0,
      "justification": "string"
    }
  ],
  "total_points": 0.0,
  "max_points": 10.0,
  "percentage": 0.0,
  "score_0_10": 0.0,
  "grade": "A",
  "feedback_sk": "5 to 7 sentences in Slovak"
}
```

---

## Grade thresholds and scoring conversion

The grading thresholds are defined in accordance with the course rules:

- **A**: 95.00–100.00%
- **B**: 90.00–94.99%
- **C**: 85.00–89.99%
- **D**: 80.00–84.99%
- **E**: 70.00–79.99%
- **Fx**: 0.00–69.99%

### Recommended scoring logic

The most transparent approach is:

- each task has rubric criteria summing to **10 points**,
- the model assigns points criterion by criterion,
- the total number of awarded points is the final **score on the 0–10 scale**,
- the percentage is computed as:

```text
percentage = (total_points / max_points) * 100
```

- the letter grade is then assigned from the percentage using the thresholds above.

If the rubric sums to 10 points, then:

```text
score_0_10 = total_points
```

This is methodologically simple and easy to justify in a paper.

---

## Shared system prompt

```text
You are an experienced university lecturer in Software Engineering and UML modelling.

Your task is to evaluate a student's UML model strictly from the Enterprise Architect XML export provided by the user. Do not evaluate the submission from an image, screenshot, or assumptions about what the diagram probably contains. Use only the XML content and the assignment context.

Evaluate the model according to the provided task-specific rubric and scoring scale. For each criterion:
- determine whether the criterion is satisfied,
- assign a justified number of points within the allowed range,
- briefly explain the reason.

Focus on both formal UML correctness and semantic adequacy with respect to the assignment context.

Important rules:
- Do not invent elements that are not present in the XML.
- If some aspect cannot be verified from the XML, explicitly state that limitation and do not award unsupported points.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML elements, properties, or relationships.
- Penalize semantically empty, vague, or purely formal compliance.
- Reward correctness, completeness, consistency, traceability, and appropriate abstraction.
- The feedback must be written in Slovak.
- The final formative feedback must be concise, specific, and pedagogically useful.
- Do not mention that you are an AI model.

Return the result strictly in valid JSON according to the required schema.
```

---

## Shared JSON output contract

```text
Return strictly valid JSON with the following fields:
- criterion_scores: array of objects with fields criterion, points_awarded, points_max, justification
- total_points
- max_points
- percentage
- score_0_10
- grade
- feedback_sk

The field feedback_sk must contain 5 to 7 sentences in Slovak.
The field score_0_10 must be on a 0.0 to 10.0 scale, rounded to one decimal place.
The field percentage must be on a 0.0 to 100.0 scale, rounded to two decimal places.
The field grade must be one of: A, B, C, D, E, Fx.
```

---

## Placeholders used in the templates

The following placeholders are intentionally explicit so that the prompts can be generated reproducibly by script:

- `{student_id}`: anonymized student identifier, if available
- `{assignment_code}`: for example `S0U1`, `S0U2`, `S0U3`, `S0U4`, `E0A1`
- `{assignment_context}`: short task statement or modelling scenario supplied to students
- `{xml_content}`: full XML export from Enterprise Architect
- `{json_schema}`: explicit JSON output contract embedded in the prompt

---

# Task-specific prompt templates

## 1. Prompt template for Requirements model

```text
Evaluate the following UML Requirements model exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Requirements model
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate. Do not award full points unless the criterion is satisfied convincingly both formally and semantically.

Criteria and maximum points:
1. Structure, coherence, and formal correctness of the requirements model, including the presence of at least 20 meaningful system requirements. (0–6 points)
2. Coverage and completeness of requirements across the main functionalities and constraints implied by the assignment context. (0–4 points)

Interpretation of point allocation:
- Full points: criterion is fulfilled clearly, correctly, and consistently.
- Partial points: criterion is only partly fulfilled, contains omissions, vague elements, inconsistencies, or formal mistakes.
- Zero points: criterion is missing, mostly incorrect, or not supported by the XML evidence.

Important evaluation rules:
- Use only the XML content below.
- Do not infer missing requirements from screenshots or expected solutions.
- Penalize vague labels, duplicates, contradictory requirements, and implementation-level statements presented instead of requirements.
- Reward clear, testable, relevant, and consistently named requirements.
- If present, consider relations such as dependency, trace, derive, refine, or similar links only when supported by the XML.
- Ignore Enterprise Architect technical metadata unless it clearly describes actual UML model content.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
```

---

## 2. Prompt template for Use Case model

```text
Evaluate the following UML Use Case model exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Use Case model
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate.

Criteria and maximum points:
1. Correct identification and naming of actors and use cases, including appropriate use case abstraction and system boundary. (0–4 points)
2. Correctness, relevance, and justification of relationships, including associations, «include», «extend», and generalization where applicable. (0–4 points)
3. Use of stereotypes or modelling conventions that improve clarity and understanding, where appropriate. (0–2 points)

Interpretation of point allocation:
- Full points: criterion is fulfilled correctly and consistently.
- Partial points: criterion is partly fulfilled, but there are omissions, misuses, weak naming, or unclear notation.
- Zero points: criterion is absent, largely incorrect, or unsupported by the XML.

Important evaluation rules:
- Use only the XML content below.
- Do not infer missing actors or use cases from an image or expected solution.
- Penalize use cases that describe technical implementation details rather than user goals.
- Penalize incorrect or unjustified «include» and «extend» relations, reversed relations, and unclear system scope.
- Reward meaningful actor roles, clear use case naming, complete coverage of main interactions, and consistent UML notation.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML elements or relationships.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
```

---

## 3. Prompt template for Class diagram

```text
Evaluate the following UML Class diagram exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Class diagram
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate.

Criteria and maximum points:
1. Presence of at least five representative classes that capture the core system structure and domain concepts. (0–2 points)
2. Correct definition of classes, including meaningful English class names, appropriate attributes, and appropriate operations where available. (0–4 points)
3. Correctness and clarity of relationships between classes, including semantic appropriateness, naming, and multiplicities where expected or available. (0–4 points)

Interpretation of point allocation:
- Full points: criterion is clearly and correctly fulfilled.
- Partial points: criterion is only partly fulfilled due to omissions, unclear naming, weak domain modelling, or formal mistakes.
- Zero points: criterion is missing, mostly incorrect, or unsupported by the XML.

Important evaluation rules:
- Use only the XML content below.
- Do not assume hidden attributes, methods, multiplicities, or relations not present in the XML.
- Penalize generic or technically irrelevant classes, weak domain abstraction, and relationships without semantic justification.
- Penalize missing multiplicities when they are important for understanding the model.
- Penalize incorrect use of inheritance, aggregation, and composition.
- Reward coherent domain modelling, meaningful responsibilities, and internally consistent structure.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML content.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
```

---

## 4. Prompt template for Activity diagram

```text
Evaluate the following UML Activity diagram exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Activity diagram
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate.

Criteria and maximum points:
1. All relevant activities are included and clearly defined with respect to the assignment context. (0–4 points)
2. The control flow is logical, readable, and includes a clearly defined start and end. (0–2 points)
3. UML activity notation and symbols are used correctly and consistently. (0–2 points)
4. Decision nodes, guards, merges, or parallel branches are modelled appropriately where needed. (0–2 points)

Interpretation of point allocation:
- Full points: criterion is clearly fulfilled and modelled correctly.
- Partial points: criterion is partly fulfilled but contains omissions, weak naming, disconnected flow, or notation problems.
- Zero points: criterion is absent, mostly incorrect, or unsupported by the XML.

Important evaluation rules:
- Use only the XML content below.
- Do not infer missing flows from screenshots or expected solutions.
- Penalize missing start or end nodes, disconnected actions, unreachable fragments, unclear or absent branch conditions, and misuse of forks/joins.
- Reward coherent process logic, clear action naming, and appropriate handling of alternatives or parallelism.
- If swimlanes or partitions are present, consider whether they are used consistently.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML content.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
```

---

# Suggested API message layout

The recommended message structure is:

```python
messages = [
    {"role": "system", "content": SHARED_SYSTEM_PROMPT},
    {"role": "user", "content": rendered_task_prompt},
]
```

---

# Reproducible Python implementation

```python
from openai import OpenAI
import json
from pathlib import Path

client = OpenAI()

SHARED_SYSTEM_PROMPT = '''
You are an experienced university lecturer in Software Engineering and UML modelling.

Your task is to evaluate a student's UML model strictly from the Enterprise Architect XML export provided by the user. Do not evaluate the submission from an image, screenshot, or assumptions about what the diagram probably contains. Use only the XML content and the assignment context.

Evaluate the model according to the provided task-specific rubric and scoring scale. For each criterion:
- determine whether the criterion is satisfied,
- assign a justified number of points within the allowed range,
- briefly explain the reason.

Focus on both formal UML correctness and semantic adequacy with respect to the assignment context.

Important rules:
- Do not invent elements that are not present in the XML.
- If some aspect cannot be verified from the XML, explicitly state that limitation and do not award unsupported points.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML elements, properties, or relationships.
- Penalize semantically empty, vague, or purely formal compliance.
- Reward correctness, completeness, consistency, traceability, and appropriate abstraction.
- The feedback must be written in Slovak.
- The final formative feedback must be concise, specific, and pedagogically useful.
- Do not mention that you are an AI model.

Return the result strictly in valid JSON according to the required schema.
'''.strip()


TASK_PROMPTS = {
    "requirements": '''
Evaluate the following UML Requirements model exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Requirements model
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate. Do not award full points unless the criterion is satisfied convincingly both formally and semantically.

Criteria and maximum points:
1. Structure, coherence, and formal correctness of the requirements model, including the presence of at least 20 meaningful system requirements. (0–6 points)
2. Coverage and completeness of requirements across the main functionalities and constraints implied by the assignment context. (0–4 points)

Interpretation of point allocation:
- Full points: criterion is fulfilled clearly, correctly, and consistently.
- Partial points: criterion is only partly fulfilled, contains omissions, vague elements, inconsistencies, or formal mistakes.
- Zero points: criterion is missing, mostly incorrect, or not supported by the XML evidence.

Important evaluation rules:
- Use only the XML content below.
- Do not infer missing requirements from screenshots or expected solutions.
- Penalize vague labels, duplicates, contradictory requirements, and implementation-level statements presented instead of requirements.
- Reward clear, testable, relevant, and consistently named requirements.
- If present, consider relations such as dependency, trace, derive, refine, or similar links only when supported by the XML.
- Ignore Enterprise Architect technical metadata unless it clearly describes actual UML model content.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
'''.strip(),

    "use_case": '''
Evaluate the following UML Use Case model exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Use Case model
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate.

Criteria and maximum points:
1. Correct identification and naming of actors and use cases, including appropriate use case abstraction and system boundary. (0–4 points)
2. Correctness, relevance, and justification of relationships, including associations, «include», «extend», and generalization where applicable. (0–4 points)
3. Use of stereotypes or modelling conventions that improve clarity and understanding, where appropriate. (0–2 points)

Interpretation of point allocation:
- Full points: criterion is fulfilled correctly and consistently.
- Partial points: criterion is partly fulfilled, but there are omissions, misuses, weak naming, or unclear notation.
- Zero points: criterion is absent, largely incorrect, or unsupported by the XML.

Important evaluation rules:
- Use only the XML content below.
- Do not infer missing actors or use cases from an image or expected solution.
- Penalize use cases that describe technical implementation details rather than user goals.
- Penalize incorrect or unjustified «include» and «extend» relations, reversed relations, and unclear system scope.
- Reward meaningful actor roles, clear use case naming, complete coverage of main interactions, and consistent UML notation.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML elements or relationships.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
'''.strip(),

    "class": '''
Evaluate the following UML Class diagram exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Class diagram
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate.

Criteria and maximum points:
1. Presence of at least five representative classes that capture the core system structure and domain concepts. (0–2 points)
2. Correct definition of classes, including meaningful English class names, appropriate attributes, and appropriate operations where available. (0–4 points)
3. Correctness and clarity of relationships between classes, including semantic appropriateness, naming, and multiplicities where expected or available. (0–4 points)

Interpretation of point allocation:
- Full points: criterion is clearly and correctly fulfilled.
- Partial points: criterion is only partly fulfilled due to omissions, unclear naming, weak domain modelling, or formal mistakes.
- Zero points: criterion is missing, mostly incorrect, or unsupported by the XML.

Important evaluation rules:
- Use only the XML content below.
- Do not assume hidden attributes, methods, multiplicities, or relations not present in the XML.
- Penalize generic or technically irrelevant classes, weak domain abstraction, and relationships without semantic justification.
- Penalize missing multiplicities when they are important for understanding the model.
- Penalize incorrect use of inheritance, aggregation, and composition.
- Reward coherent domain modelling, meaningful responsibilities, and internally consistent structure.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML content.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
'''.strip(),

    "activity": '''
Evaluate the following UML Activity diagram exported from Enterprise Architect.

Student identifier: {student_id}
Assignment code: {assignment_code}
Diagram type: Activity diagram
Assignment context:
{assignment_context}

Scoring instructions:
Evaluate the model against the criteria below. Assign partial points where appropriate.

Criteria and maximum points:
1. All relevant activities are included and clearly defined with respect to the assignment context. (0–4 points)
2. The control flow is logical, readable, and includes a clearly defined start and end. (0–2 points)
3. UML activity notation and symbols are used correctly and consistently. (0–2 points)
4. Decision nodes, guards, merges, or parallel branches are modelled appropriately where needed. (0–2 points)

Interpretation of point allocation:
- Full points: criterion is clearly fulfilled and modelled correctly.
- Partial points: criterion is partly fulfilled but contains omissions, weak naming, disconnected flow, or notation problems.
- Zero points: criterion is absent, mostly incorrect, or unsupported by the XML.

Important evaluation rules:
- Use only the XML content below.
- Do not infer missing flows from screenshots or expected solutions.
- Penalize missing start or end nodes, disconnected actions, unreachable fragments, unclear or absent branch conditions, and misuse of forks/joins.
- Reward coherent process logic, clear action naming, and appropriate handling of alternatives or parallelism.
- If swimlanes or partitions are present, consider whether they are used consistently.
- Ignore Enterprise Architect technical metadata unless it clearly represents actual UML content.

Scoring conversion rules:
- max_points = 10
- percentage = (total_points / max_points) * 100
- score_0_10 = total_points
- grade thresholds:
  * A: 95.00–100.00
  * B: 90.00–94.99
  * C: 85.00–89.99
  * D: 80.00–84.99
  * E: 70.00–79.99
  * Fx: 0.00–69.99

Return strictly valid JSON with this structure:
{json_schema}

Enterprise Architect XML:
```xml
{xml_content}
```
'''.strip()
}


JSON_SCHEMA_TEXT = '''
{
  "criterion_scores": [
    {
      "criterion": "string",
      "points_awarded": 0.0,
      "points_max": 0.0,
      "justification": "string"
    }
  ],
  "total_points": 0.0,
  "max_points": 10.0,
  "percentage": 0.0,
  "score_0_10": 0.0,
  "grade": "A",
  "feedback_sk": "5 to 7 sentences in Slovak"
}
'''.strip()


def render_prompt(
    task_type: str,
    student_id: str,
    assignment_code: str,
    assignment_context: str,
    xml_content: str
) -> str:
    if task_type not in TASK_PROMPTS:
        raise ValueError(f"Unsupported task_type: {task_type}")

    return TASK_PROMPTS[task_type].format(
        student_id=student_id,
        assignment_code=assignment_code,
        assignment_context=assignment_context,
        xml_content=xml_content,
        json_schema=JSON_SCHEMA_TEXT
    )


def evaluate_uml_model(
    task_type: str,
    student_id: str,
    assignment_code: str,
    assignment_context: str,
    xml_path: str,
    model_name: str = "gpt-4.1"
) -> dict:
    xml_content = Path(xml_path).read_text(encoding="utf-8")
    user_prompt = render_prompt(
        task_type=task_type,
        student_id=student_id,
        assignment_code=assignment_code,
        assignment_context=assignment_context,
        xml_content=xml_content
    )

    response = client.chat.completions.create(
        model=model_name,
        temperature=0.2,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SHARED_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
    )

    raw_content = response.choices[0].message.content
    result = json.loads(raw_content)

    return {
        "student_id": student_id,
        "assignment_code": assignment_code,
        "task_type": task_type,
        "xml_path": xml_path,
        "evaluation": result
    }
```


```python
def render_human_readable_output(evaluation: dict) -> str:
    e = evaluation["evaluation"]
    return (
        f"SPÄTNÁ VÄZBA:\n{e['feedback_sk']}\n\n"
        f"SKÓRE: {e['score_0_10']:.1f}\n"
        f"ZNÁMKA: {e['grade']}"
    )
```

```python
result = evaluate_uml_model(
    task_type="class",
    student_id="anon_025",
    assignment_code="S0U3",
    assignment_context="Model a class diagram for an information system used to manage hotel reservations.",
    xml_path="data/S0U3/anon_025.xml",
    model_name="gpt-4.1"
)

print(json.dumps(result, ensure_ascii=False, indent=2))
print()
print(render_human_readable_output(result))
```
