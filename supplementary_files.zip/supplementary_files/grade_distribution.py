#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from common import (
    CONDITION_LABELS,
    CONDITION_ORDER,
    GRADE_ORDER,
    ensure_outdir,
    normalize_condition,
    normalize_grade,
    read_csv_flexible,
    sorted_unique,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-dir", default=Path("outputs/figure2"), type=Path)
    parser.add_argument("--condition-column", default="G")
    parser.add_argument("--grade-column", default="FG")
    parser.add_argument("--figure-name", default="figure2_final_grade_distribution.png")
    parser.add_argument("--title", default="Final grade distribution by feedback condition")
    parser.add_argument("--annotate", action="store_true")
    return parser.parse_args()


def prepare_grade_data(df: pd.DataFrame, condition_column: str = "G", grade_column: str = "FG") -> pd.DataFrame:
    missing = [c for c in [condition_column, grade_column] if c not in df.columns]
    if missing:
        raise SystemExit(f"Input CSV is missing required column(s): {', '.join(missing)}")

    clean = df[[condition_column, grade_column]].copy()
    clean["condition"] = clean[condition_column].map(normalize_condition)
    clean["grade"] = clean[grade_column].map(normalize_grade)
    clean = clean[clean["condition"].notna() & clean["grade"].notna()].copy()
    if clean.empty:
        raise SystemExit("No valid rows remained after normalizing feedback conditions and final grades.")
    return clean


def build_grade_distribution_matrices(clean: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    conditions = sorted_unique(clean["condition"].unique(), preferred_order=CONDITION_ORDER)
    grades = sorted_unique(clean["grade"].unique(), preferred_order=GRADE_ORDER)

    counts_long = (
        clean.groupby(["condition", "grade"])
        .size()
        .rename("n")
        .reset_index()
    )
    totals = counts_long.groupby("condition")["n"].sum().rename("condition_total").reset_index()
    counts_long = counts_long.merge(totals, on="condition", how="left")
    counts_long["percentage"] = counts_long["n"] / counts_long["condition_total"] * 100
    counts_long["condition_label"] = counts_long["condition"].map(CONDITION_LABELS).fillna(counts_long["condition"])

    count_matrix = pd.DataFrame(0, index=grades, columns=conditions, dtype=int)
    percent_matrix = pd.DataFrame(0.0, index=grades, columns=conditions, dtype=float)
    for _, row in counts_long.iterrows():
        count_matrix.loc[row["grade"], row["condition"]] = int(row["n"])
        percent_matrix.loc[row["grade"], row["condition"]] = float(row["percentage"])
    return count_matrix, percent_matrix.round(2), counts_long.sort_values(["condition", "grade"])


def plot_grade_distribution(percent_matrix: pd.DataFrame, output_path: Path, title: str, annotate: bool = False) -> None:
    grades = list(percent_matrix.index)
    conditions = list(percent_matrix.columns)
    display_conditions = [CONDITION_LABELS.get(c, c) for c in conditions]
    x = np.arange(len(grades))
    n_conditions = len(conditions)
    total_width = 0.78
    width = total_width / max(1, n_conditions)

    fig, ax = plt.subplots(figsize=(max(9, len(grades) * 1.35), 6.2))
    for idx, condition in enumerate(conditions):
        offset = (idx - (n_conditions - 1) / 2) * width
        values = percent_matrix[condition].to_numpy(dtype=float)
        bars = ax.bar(x + offset, values, width, label=display_conditions[idx])
        if annotate:
            for bar, value in zip(bars, values):
                if value > 0:
                    ax.text(bar.get_x() + bar.get_width() / 2, value + 0.8, f"{value:.1f}%", ha="center", va="bottom", fontsize=8)

    ax.set_title(title, fontsize=14, pad=12)
    ax.set_xlabel("Final grade")
    ax.set_ylabel("Percentage within condition")
    ax.set_xticks(x)
    ax.set_xticklabels(grades)
    max_value = float(np.nanmax(percent_matrix.to_numpy(dtype=float))) if not percent_matrix.empty else 0.0
    ax.set_ylim(0, max(5, max_value + 8))
    ax.legend(title="Feedback condition")
    fig.tight_layout()
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def compute_grade_pipeline(
    input_path: Path,
    output_dir: Path,
    condition_column: str = "G",
    grade_column: str = "FG",
    figure_name: str = "figure2_final_grade_distribution.png",
    title: str = "Final grade distribution by feedback condition",
    annotate: bool = False,
) -> dict[str, Path]:
    outdir = ensure_outdir(output_dir)
    df = read_csv_flexible(input_path)
    clean = prepare_grade_data(df, condition_column=condition_column, grade_column=grade_column)
    count_matrix, percent_matrix, long_table = build_grade_distribution_matrices(clean)

    outputs = {
        "grade_count_matrix": outdir / "figure2_grade_count_matrix.csv",
        "grade_percent_matrix": outdir / "figure2_grade_percent_matrix.csv",
        "grade_distribution_long": outdir / "figure2_grade_distribution_long.csv",
        "clean_rows": outdir / "figure2_clean_grade_rows.csv",
        "figure": outdir / figure_name,
        "metadata": outdir / "figure2_run_metadata.json",
    }
    count_matrix.to_csv(outputs["grade_count_matrix"], encoding="utf-8-sig")
    percent_matrix.to_csv(outputs["grade_percent_matrix"], encoding="utf-8-sig")
    long_table.to_csv(outputs["grade_distribution_long"], index=False, encoding="utf-8-sig")
    clean.to_csv(outputs["clean_rows"], index=False, encoding="utf-8-sig")
    plot_grade_distribution(percent_matrix, outputs["figure"], title=title, annotate=annotate)

    metadata = {
        "input_path": str(input_path),
        "n_rows_loaded": int(df.shape[0]),
        "n_valid_grade_rows": int(clean.shape[0]),
        "condition_column": condition_column,
        "grade_column": grade_column,
        "conditions": list(percent_matrix.columns),
        "grades": list(percent_matrix.index),
        "outputs": {k: str(v) for k, v in outputs.items()},
    }
    outputs["metadata"].write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return outputs


def main() -> None:
    args = parse_args()
    outputs = compute_grade_pipeline(
        input_path=args.input,
        output_dir=args.output_dir,
        condition_column=args.condition_column,
        grade_column=args.grade_column,
        figure_name=args.figure_name,
        title=args.title,
        annotate=args.annotate,
    )
    print("Computed Figure 2 and grade matrices from input data:")
    for key, path in outputs.items():
        print(f"  {key}: {path}")


if __name__ == "__main__":
    main()
