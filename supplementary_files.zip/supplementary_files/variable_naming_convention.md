# Variable naming convention

The CSV files retain the original course-export naming scheme. The main patterns are:

- `S0U1`-`S0U4`: semester UML tasks. In the released course sequence these correspond to Requirements, Use Case, Activity, and Class models.
- `E0A1`-`E0A3`: exam UML tasks stored at student/feedback level.
- `E0A4`: auxiliary raw XML export folder for sequence diagrams. These files are preserved in `xml_models.zip` for completeness but are not represented as a separate feedback column in `feedback_data25.csv`.
- suffix `A`: assignment or scenario variant.
- suffix `S`: numeric score.
- suffix `G`: letter grade.
- suffix `F` in `student_data25.csv`: helpfulness rating for a semester-task feedback event.
- suffix `F` in `feedback_data25.csv`: feedback text for a semester task.
- suffix `LS` in `feedback_data25.csv`: student helpfulness rating on the 1-5 ordinal scale documented in `survey_note.md`.
- columns `AM*` / `AJ*`: numeric scores from two human annotators, Teacher M and Teacher J.
- columns `MG*` / `JG*`: corresponding letter grades from Teacher M and Teacher J.
- `FG`: final course grade.

The file suffix `25` in `student_data25.csv` and `feedback_data25.csv` refers to the 2025 semester export within academic year 2024/2025. It does not denote a separate 2024 and 2025 two-cohort public release.
