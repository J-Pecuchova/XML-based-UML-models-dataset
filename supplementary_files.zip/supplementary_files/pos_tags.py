#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from common import (
    CONDITION_ORDER,
    detect_student_id_column,
    ensure_outdir,
    find_feedback_text_columns,
    label_for_task_condition,
    normalize_condition,
    order_task_condition_labels,
    read_csv_flexible,
)


POS_GROUP_ORDER: list[str] = [
    "Nouns",
    "Adjectives",
    "Verbs",
    "Determiners",
    "Adpositions",
    "Adverbs",
    "Pronouns",
    "Auxiliaries",
    "Numerals",
    "Particles",
    "Others",
]

UPOS_TO_GROUP: dict[str, str] = {
    "NOUN": "Nouns",
    "PROPN": "Nouns",
    "ADJ": "Adjectives",
    "VERB": "Verbs",
    "DET": "Determiners",
    "ADP": "Adpositions",
    "ADV": "Adverbs",
    "PRON": "Pronouns",
    "AUX": "Auxiliaries",
    "NUM": "Numerals",
    "PART": "Particles",
}
IGNORED_UPOS: set[str] = {"PUNCT", "SYM", "SPACE", "X"}
WORD_RE = re.compile(r"\b[\wÁÄČĎÉÍĹĽŇÓÔŔŠŤÚÝŽáäčďéíĺľňóôŕšťúýž]+\b", re.UNICODE)


@dataclass(frozen=True)
class FeedbackItem:
    row_index: int
    source_id: object
    student_id: object
    condition: str
    task_column: str
    label: str
    text: str
    word_count: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
    )
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-dir", default=Path("outputs/figure1"))
    parser.add_argument("--condition-column", default="G")
    parser.add_argument("--feedback-columns", nargs="*")
    parser.add_argument("--student-id-column")
    parser.add_argument("--lang", default="sk")
    parser.add_argument("--download-stanza", action="store_true")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--no-token-export", action="store_true")
    parser.add_argument("--figure-name", default="figure1_pos_composition_heatmap.png")
    parser.add_argument("--title", default="POS composition of feedback texts")
    return parser.parse_args()


def word_count(text: object) -> int:
    if text is None or pd.isna(text):
        return 0
    return len(WORD_RE.findall(str(text)))


def make_stanza_pipeline(lang: str = "sk", download: bool = False):
    try:
        import stanza
    except ImportError as exc: 
        raise SystemExit(
        ) from exc

    if download:
        stanza.download(lang)
    return stanza.Pipeline(lang=lang, processors="tokenize,pos", use_gpu=False, verbose=False)


def group_upos(upos: str | None) -> str | None:
    if not upos:
        return None
    upos = upos.upper()
    if upos in IGNORED_UPOS:
        return None
    return UPOS_TO_GROUP.get(upos, "Others")


def validate_columns(df: pd.DataFrame, condition_column: str, feedback_columns: list[str]) -> None:
    missing = [c for c in [condition_column, *feedback_columns] if c not in df.columns]
    if missing:
        raise SystemExit(f"Input CSV is missing required column(s): {', '.join(missing)}")
    if not feedback_columns:
        raise SystemExit(
        )


def iter_feedback_items(
    df: pd.DataFrame,
    feedback_columns: Iterable[str],
    condition_column: str = "G",
    student_id_column: str | None = None,
) -> Iterable[FeedbackItem]:
    student_col = student_id_column or detect_student_id_column(df.columns)
    for row_index, row in df.iterrows():
        condition = normalize_condition(row.get(condition_column))
        if condition not in {"T", "AI"}:
            continue
        for col in feedback_columns:
            text = row.get(col)
            if text is None or pd.isna(text) or not str(text).strip():
                continue
            yield FeedbackItem(
                row_index=int(row_index),
                source_id=row.get("Id", row_index + 1),
                student_id=row.get(student_col, "") if student_col else "",
                condition=condition,
                task_column=col,
                label=label_for_task_condition(col, condition),
                text=str(text),
                word_count=word_count(text),
            )


def tag_feedback_items(items: Iterable[FeedbackItem], nlp, export_tokens: bool = True, batch_size: int = 16) -> tuple[pd.DataFrame, pd.DataFrame]:
    token_rows: list[dict] = []
    item_rows: list[dict] = []

    for index, item in enumerate(items, start=1):
        item_rows.append(asdict(item))
        doc = nlp(item.text)
        for sentence_index, sentence in enumerate(doc.sentences, start=1):
            for token_index, word in enumerate(sentence.words, start=1):
                upos = getattr(word, "upos", None)
                group = group_upos(upos)
                if group is None:
                    continue
                if export_tokens:
                    token_rows.append({
                        "row_index": item.row_index,
                        "source_id": item.source_id,
                        "student_id": item.student_id,
                        "condition": item.condition,
                        "task_column": item.task_column,
                        "label": item.label,
                        "sentence_index": sentence_index,
                        "token_index": token_index,
                        "token": getattr(word, "text", ""),
                        "upos": upos,
                        "pos_group": group,
                    })
                else:
                    token_rows.append({
                        "condition": item.condition,
                        "task_column": item.task_column,
                        "label": item.label,
                        "upos": upos,
                        "pos_group": group,
                    })
        if batch_size > 0 and index % batch_size == 0:
            print(f"Tagged {index} feedback items...")

    return pd.DataFrame(token_rows), pd.DataFrame(item_rows)


def build_pos_matrices(tokens: pd.DataFrame, labels: list[str] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if tokens.empty:
        raise SystemExit("No POS tokens were produced. Check the feedback text columns and language model.")

    labels = labels or order_task_condition_labels(tokens["label"].dropna().unique())
    counts_long = (
        tokens.groupby(["label", "pos_group"])
        .size()
        .rename("n")
        .reset_index()
    )
    totals = counts_long.groupby("label")["n"].sum().rename("label_total").reset_index()
    counts_long = counts_long.merge(totals, on="label", how="left")
    counts_long["percentage"] = counts_long["n"] / counts_long["label_total"] * 100

    count_matrix = pd.DataFrame(0, index=POS_GROUP_ORDER, columns=labels, dtype=int)
    percent_matrix = pd.DataFrame(0.0, index=POS_GROUP_ORDER, columns=labels, dtype=float)

    for _, row in counts_long.iterrows():
        label = row["label"]
        group = row["pos_group"]
        if label in count_matrix.columns and group in count_matrix.index:
            count_matrix.loc[group, label] = int(row["n"])
            percent_matrix.loc[group, label] = float(row["percentage"])

    upos_matrix = (
        tokens.groupby(["upos", "label"])
        .size()
        .unstack("label", fill_value=0)
        .reindex(columns=labels, fill_value=0)
        .sort_index()
    )
    return count_matrix, percent_matrix.round(2), counts_long, upos_matrix


def build_length_summary(items: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    if items.empty:
        return pd.DataFrame(), pd.DataFrame()

    by_label = (
        items.groupby(["label", "condition", "task_column"])["word_count"]
        .agg(n_texts="count", mean_words="mean", sd_words="std", median_words="median", min_words="min", max_words="max")
        .reset_index()
    )
    by_condition = (
        items.groupby("condition")["word_count"]
        .agg(n_texts="count", mean_words="mean", sd_words="std", median_words="median", min_words="min", max_words="max")
        .reset_index()
    )
    numeric_cols = ["mean_words", "sd_words", "median_words"]
    by_label[numeric_cols] = by_label[numeric_cols].round(2)
    by_condition[numeric_cols] = by_condition[numeric_cols].round(2)
    return by_label, by_condition


def plot_heatmap(percent_matrix: pd.DataFrame, output_path: Path, title: str) -> None:
    matrix = percent_matrix.reindex(index=POS_GROUP_ORDER).fillna(0.0)
    data = matrix.to_numpy(dtype=float)
    vmax = max(1.0, float(np.nanmax(data)))

    fig_width = max(10, matrix.shape[1] * 1.25)
    fig_height = max(6, matrix.shape[0] * 0.55)
    fig, ax = plt.subplots(figsize=(fig_width, fig_height))
    im = ax.imshow(data, aspect="auto", vmin=0, vmax=vmax)

    ax.set_title(title, fontsize=14, pad=12)
    ax.set_xlabel("Assignment and feedback condition")
    ax.set_ylabel("POS group")
    ax.set_xticks(np.arange(matrix.shape[1]))
    ax.set_xticklabels(matrix.columns, rotation=45, ha="right")
    ax.set_yticks(np.arange(matrix.shape[0]))
    ax.set_yticklabels(matrix.index)

    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            value = data[i, j]
            label = "0" if abs(value) < 0.005 else f"{value:.1f}"
            ax.text(j, i, label, ha="center", va="center", fontsize=8)

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Percentage within feedback subset")
    fig.tight_layout()
    fig.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def compute_pos_pipeline(
    input_path: Path,
    output_dir: Path,
    condition_column: str = "G",
    feedback_columns: list[str] | None = None,
    student_id_column: str | None = None,
    lang: str = "sk",
    download_stanza: bool = False,
    export_tokens: bool = True,
    batch_size: int = 16,
    figure_name: str = "figure1_pos_composition_heatmap.png",
    title: str = "POS composition of feedback texts",
) -> dict[str, Path]:
    outdir = ensure_outdir(output_dir)
    df = read_csv_flexible(input_path)
    feedback_columns = feedback_columns or find_feedback_text_columns(df.columns)
    validate_columns(df, condition_column, feedback_columns)

    items = list(iter_feedback_items(df, feedback_columns, condition_column, student_id_column))
    if not items:
        raise SystemExit("No feedback items were found after filtering for T/AI conditions and non-empty text.")

    labels = order_task_condition_labels([item.label for item in items])
    nlp = make_stanza_pipeline(lang=lang, download=download_stanza)
    tokens, item_df = tag_feedback_items(items, nlp=nlp, export_tokens=export_tokens, batch_size=batch_size)
    count_matrix, percent_matrix, counts_long, upos_matrix = build_pos_matrices(tokens, labels=labels)
    length_by_label, length_by_condition = build_length_summary(item_df)

    outputs = {
        "pos_count_matrix": outdir / "figure1_pos_count_matrix.csv",
        "pos_percent_matrix": outdir / "figure1_pos_percent_matrix.csv",
        "pos_counts_long": outdir / "figure1_pos_counts_long.csv",
        "upos_count_matrix": outdir / "figure1_upos_count_matrix.csv",
        "feedback_items": outdir / "figure1_feedback_items.csv",
        "length_by_label": outdir / "figure1_feedback_length_by_label.csv",
        "length_by_condition": outdir / "figure1_feedback_length_by_condition.csv",
        "figure": outdir / figure_name,
        "metadata": outdir / "figure1_run_metadata.json",
    }
    if export_tokens:
        outputs["tokens"] = outdir / "figure1_pos_tokens.csv"

    count_matrix.to_csv(outputs["pos_count_matrix"], encoding="utf-8-sig")
    percent_matrix.to_csv(outputs["pos_percent_matrix"], encoding="utf-8-sig")
    counts_long.to_csv(outputs["pos_counts_long"], index=False, encoding="utf-8-sig")
    upos_matrix.to_csv(outputs["upos_count_matrix"], encoding="utf-8-sig")
    item_df.to_csv(outputs["feedback_items"], index=False, encoding="utf-8-sig")
    length_by_label.to_csv(outputs["length_by_label"], index=False, encoding="utf-8-sig")
    length_by_condition.to_csv(outputs["length_by_condition"], index=False, encoding="utf-8-sig")
    if export_tokens:
        tokens.to_csv(outputs["tokens"], index=False, encoding="utf-8-sig")
    plot_heatmap(percent_matrix, outputs["figure"], title=title)

    metadata = {
        "input_path": str(input_path),
        "n_rows_loaded": int(df.shape[0]),
        "feedback_columns": feedback_columns,
        "condition_column": condition_column,
        "student_id_column": student_id_column or detect_student_id_column(df.columns),
        "n_feedback_items": int(item_df.shape[0]),
        "n_pos_tokens": int(tokens.shape[0]),
        "labels": labels,
        "outputs": {k: str(v) for k, v in outputs.items()},
    }
    outputs["metadata"].write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return outputs


def main() -> None:
    args = parse_args()
    outputs = compute_pos_pipeline(
        input_path=args.input,
        output_dir=args.output_dir,
        condition_column=args.condition_column,
        feedback_columns=args.feedback_columns,
        student_id_column=args.student_id_column,
        lang=args.lang,
        download_stanza=args.download_stanza,
        export_tokens=not args.no_token_export,
        batch_size=args.batch_size,
        figure_name=args.figure_name,
        title=args.title,
    )
    print("Computed Figure 1 and POS matrices from input data:")
    for key, path in outputs.items():
        print(f"  {key}: {path}")


if __name__ == "__main__":
    main()
