# Example row fragments

The full CSV files contain long Slovak feedback paragraphs. The fragments below show the row structure using selected columns only; they do not replace the full `student_data25.csv` or `feedback_data25.csv` tables.

## student_data25.csv, selected columns

|   Id |   Student | A   |   Y |   AY |   A1 | A1G   |   S0U1S | S0U1G   |   S0U1F | FG   |
|-----:|----------:|:----|----:|-----:|-----:|:------|--------:|:--------|--------:|:-----|
|    1 |    290125 | B   |   2 | 2025 | 6.5  | Fx    |       8 | D       |       5 | C    |
|    2 |    290126 | B   |   2 | 2025 | 6.33 | Fx    |       9 | B       |       4 | C    |
|    3 |    290127 | C   |   2 | 2025 | 9.33 | B     |       4 | Fx      |       5 | E    |

## feedback_data25.csv, selected columns

|   Id |   StudentNo | G   | S0U1A   | S0U1                                 |   S0U1S | S0U1G   |   S0U1LS | E0A1A   |   AM1 |   AJ1 | FG   |
|-----:|------------:|:----|:--------|:-------------------------------------|--------:|:--------|---------:|:--------|------:|------:|:-----|
|    1 |      290125 | Ai  | B       | /images/S0U1/290125_requirements.png |       8 | D       |        5 | B       |    10 |     9 | C    |
|    2 |      290126 | Ai  | B       | /images/S0U1/290126_requirements.png |       9 | B       |        4 | B       |     8 |     8 | C    |
|    3 |      290127 | Ai  | C       | /images/S0U1/290127_requirements.png |       4 | Fx      |        5 | C       |     5 |     4 | E    |
